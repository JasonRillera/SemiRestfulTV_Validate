from django.apps import AppConfig


class ShowsConfig(AppConfig):
    name = 'shows'
